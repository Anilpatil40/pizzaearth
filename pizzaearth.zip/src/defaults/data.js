export const pizzas = [
  {
    label: "Pizza ABC",
    description:
      "We are currently serving one pizza only. Please taste and review",
    price: 20,
    addOns: 5,
    discount: 10,
    image: "/images/pizza1.png",
  },
];
